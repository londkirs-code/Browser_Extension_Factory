(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(e){let t=e.browser??e.chrome;if(!t)throw Error(`No WebExtensions browser API is available in this context.`);return t}function r(){return n(globalThis)}function i(e,t,n){try{let i=(n??r()).i18n?.getMessage(e);return i?.trim()?i:t}catch{return t}}function a(e){try{return(e??r()).i18n?.getUILanguage?.()??`en`}catch{return`en`}}function o(e){return{async send(t,n){return await e.sendMessage({type:t,payload:n})},on(t,n){let r=(e,r)=>{if(!e||typeof e!=`object`)return;let i=e;if(i.type===t)return n(i.payload,r)};return e.onMessage.addListener(r),()=>e.onMessage.removeListener?.(r)}}}function s(e,t,n,r,i,a){let o=Math.min(Math.max(e,0),i),s=Math.min(Math.max(t,0),a),c=Math.min(Math.max(n,0),i),l=Math.min(Math.max(r,0),a);return{left:Math.min(o,c),top:Math.min(s,l),width:Math.abs(c-o),height:Math.abs(l-s)}}function c(e,t=8){return e.width>=t&&e.height>=t}function l(e,t,n){if(n<=0||t<=0)throw Error(`Image and viewport widths must be positive.`);let r=t/n,i=Math.round(e.left*r),a=Math.round(e.top*r),o=Math.max(1,Math.round(e.width*r)),s=Math.max(1,Math.round(e.height*r)),c=s<40?Math.min(3,Math.ceil(40/s)):1;return{sx:i,sy:a,sw:o,sh:s,outputWidth:o*c,outputHeight:s*c}}async function u(e,t){let n=new Image;n.src=e,await n.decode();let r=l(t,n.naturalWidth,window.innerWidth),i=Math.min(r.sw,n.naturalWidth-r.sx),a=Math.min(r.sh,n.naturalHeight-r.sy);if(i<=0||a<=0)throw Error(`The selected area is outside the captured viewport.`);let o=document.createElement(`canvas`);o.width=Math.max(1,Math.round(r.outputWidth/r.sw*i)),o.height=Math.max(1,Math.round(r.outputHeight/r.sh*a));let s=o.getContext(`2d`);if(!s)throw Error(`Could not prepare the selected image.`);return s.filter=`grayscale(1)`,s.imageSmoothingEnabled=!0,s.imageSmoothingQuality=`high`,s.drawImage(n,r.sx,r.sy,i,a,0,0,o.width,o.height),o.toDataURL(`image/png`)}function d(e){if(e&&typeof e==`object`){let t=e;return{name:typeof t.name==`string`?t.name:`Error`,message:typeof t.message==`string`?t.message:String(e),...typeof t.stack==`string`?{stack:t.stack}:{}}}return{name:`Error`,message:String(e)}}var f=class extends Error{stage;originalError;constructor(e,t){let n=d(t);super(`${e} · ${n.name}: ${n.message}`),this.stage=e,this.originalError=t,this.name=n.name}};async function p(e,t){try{return await t()}catch(t){throw new f(e,t)}}function m(e,t,n,r){document.getElementById(`page-ocr-result-host`)?.remove();let i=document.createElement(`div`);i.id=`page-ocr-result-host`,i.style.cssText=`all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;`;let a=i.attachShadow({mode:`closed`});a.innerHTML=`
    <style>
      .panel {
        position: fixed; right: 20px; bottom: 20px; width: min(460px, calc(100vw - 40px));
        max-height: min(70vh, 620px); box-sizing: border-box; padding: 16px;
        display: flex; flex-direction: column; gap: 12px; pointer-events: auto;
        color: #172033; background: #fff; border: 1px solid #d9dfeb;
        border-radius: 12px; box-shadow: 0 12px 40px rgba(0,0,0,.24);
        font: 14px/1.5 system-ui, sans-serif;
      }
      .header { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
      .title { margin: 0; font-size: 16px; font-weight: 700; }
      .close { border: 0; background: transparent; color: #536078; font-size: 22px; cursor: pointer; }
      .message { margin: 0; color: #536078; white-space: pre-wrap; overflow-wrap: anywhere; }
      textarea {
        box-sizing: border-box; width: 100%; min-height: 130px; max-height: 42vh;
        resize: vertical; padding: 10px; border: 1px solid #c8d0df; border-radius: 8px;
        color: #172033; background: #fff; font: 14px/1.6 system-ui, sans-serif;
      }
      .actions { display: flex; align-items: center; gap: 10px; }
      .copy {
        border: 0; border-radius: 8px; padding: 9px 14px; background: #1769e0;
        color: white; font: 600 14px system-ui, sans-serif; cursor: pointer;
      }
      .status { color: #536078; font-size: 12px; }
      button:focus-visible, textarea:focus-visible { outline: 3px solid #80b5ff; outline-offset: 2px; }
    </style>
    <section class="panel" role="dialog" aria-modal="false" aria-labelledby="page-ocr-title">
      <div class="header">
        <h2 class="title" id="page-ocr-title"></h2>
        <button class="close" type="button" aria-label="Close">×</button>
      </div>
      <p class="message"></p>
      <textarea readonly spellcheck="false"></textarea>
      <div class="actions">
        <button class="copy" type="button"></button>
        <span class="status" role="status" aria-live="polite"></span>
      </div>
    </section>
  `;let o=a.querySelector(`.panel`),s=a.querySelector(`.title`),c=a.querySelector(`.message`),l=a.querySelector(`textarea`),u=a.querySelector(`.copy`),d=a.querySelector(`.close`),f=a.querySelector(`.status`);o.dir=t?`rtl`:`ltr`,s.textContent=r.title,c.textContent=n,l.value=e,l.dir=t?`rtl`:`ltr`,u.textContent=r.copy,d.textContent=`×`,d.setAttribute(`aria-label`,r.close),u.disabled=!e,u.style.opacity=e?`1`:`.5`,u.addEventListener(`click`,async()=>{try{await navigator.clipboard.writeText(l.value),f.textContent=r.copied}catch{l.focus(),l.select(),f.textContent=r.copyFailed}}),d.addEventListener(`click`,()=>i.remove()),document.documentElement.append(i)}var h=e({registration:`runtime`,matches:[],main(){let e=window;if(e.__pageOcrSelectionActive)return;e.__pageOcrSelectionActive=!0;let n=o(t.runtime),r=a().toLowerCase().startsWith(`he`),l={title:i(`resultTitle`,`Recognized text`),copy:i(`copyText`,`Copy text`),copied:i(`copied`,`Copied to clipboard`),copyFailed:i(`copyFailed`,`Select the text and copy it manually.`),close:i(`close`,`Close`)},h=document.createElement(`div`);h.style.cssText=`all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:auto;`;let g=h.attachShadow({mode:`closed`});g.innerHTML=`
      <style>
        :host { all: initial; }
        .shade {
          position: fixed; inset: 0; cursor: crosshair;
          background: rgba(12, 16, 24, .16);
          touch-action: none; user-select: none;
        }
        .selection {
          position: fixed; display: none; box-sizing: border-box;
          border: 2px solid #fff; outline: 1px solid #1769e0;
          background: rgba(45, 120, 230, .12);
          box-shadow: 0 0 0 99999px rgba(12, 16, 24, .2);
        }
        .hint {
          position: fixed; top: 18px; left: 50%; transform: translateX(-50%);
          max-width: calc(100vw - 32px); padding: 9px 14px;
          border-radius: 8px; background: #172033; color: white;
          font: 14px/1.4 system-ui, sans-serif; direction: ltr;
          box-shadow: 0 4px 18px rgba(0,0,0,.25); white-space: nowrap;
        }
      </style>
      <div class="shade">
        <div class="hint"></div>
        <div class="selection"></div>
      </div>
    `;let _=g.querySelector(`.shade`),v=g.querySelector(`.selection`),y=g.querySelector(`.hint`);y.textContent=i(`selectArea`,`Drag to select an area. Press Esc to cancel.`),y.dir=r?`rtl`:`ltr`,document.documentElement.append(h);let b=0,x=0,S=!1,C=!1,w=()=>{C||(C=!0,window.removeEventListener(`keydown`,T,!0),h.remove(),e.__pageOcrSelectionActive=!1)},T=e=>{e.key===`Escape`&&w()},E=(e,t)=>{let n=s(b,x,e,t,window.innerWidth,window.innerHeight);v.style.display=`block`,v.style.left=`${n.left}px`,v.style.top=`${n.top}px`,v.style.width=`${n.width}px`,v.style.height=`${n.height}px`};_.addEventListener(`pointerdown`,e=>{e.button!==0||C||(e.preventDefault(),b=e.clientX,x=e.clientY,S=!0,_.setPointerCapture(e.pointerId),E(b,x))}),_.addEventListener(`pointermove`,e=>{S&&!C&&(e.preventDefault(),E(e.clientX,e.clientY))}),_.addEventListener(`pointerup`,async e=>{if(!S||C)return;e.preventDefault(),S=!1;let t=s(b,x,e.clientX,e.clientY,window.innerWidth,window.innerHeight);if(w(),c(t))try{await new Promise(e=>requestAnimationFrame(()=>requestAnimationFrame(()=>e())));let e=await p(`capture`,()=>n.send(`page-ocr:capture-visible`,{}));if(`error`in e)throw new f(`capture`,e.error);let a=await p(`crop`,()=>u(e.dataUrl,t)),o=await p(`recognize`,()=>n.send(`page-ocr:recognize`,{imageDataUrl:a}));if(`error`in o)throw new f(`recognize`,o.error);m(o.text,r,o.text?``:i(`noText`,`No readable text was found in that area.`),l)}catch(e){let t=e instanceof f?e:new f(`capture`,e),n=d(t.originalError);console.error(`Page OCR failed`,{stage:t.stage,name:n.name,message:n.message,stack:n.stack},t.originalError),m(``,r,`${i(`ocrFailed`,`OCR failed`)}: ${t.stage} · ${n.name}: ${n.message}`,l)}}),_.addEventListener(`pointercancel`,w),window.addEventListener(`keydown`,T,!0)}}),g={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},_=class e extends Event{static EVENT_NAME=v(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function v(e){return`${t?.runtime?.id}:content:${e}`}var y=typeof globalThis.navigation?.addEventListener==`function`;function b(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),y?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new _(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new _(e,t)),t=e)},1e3))}}}var x=class e{static SCRIPT_STARTED_MESSAGE_TYPE=v(`wxt:content-script-started`);id;abortController;locationWatcher=b(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?v(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),g.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},S={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=h;return await e(new x(`content`,t))}catch(e){throw S.error(`The content script "content" crashed on startup!`,e),e}})()})();